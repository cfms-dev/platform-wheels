'''Example package for pre-built wheels demonstration.'''

__version__ = '1.0.0'

def hello():
    return 'Hello from pre-built wheel!'
